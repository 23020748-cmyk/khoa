lsb_release -a
sudo apt update && sudo apt install locales software-properties-common curl -y
sudo locale-gen en_US en_US.UTF-8
sudo update-locale LC_ALL=en_US.UTF-8 LANG=en_US.UTF-8
export LANG=en_US.UTF-8
sudo add-apt-repository universe -y
sudo curl -sSL https://raw.githubusercontent.com/ros2/ros2/main/ros2-apt-repository-key.gpg -o /usr/share/keyrings/ros-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/ros-archive-keyring.gpg] http://packages.ros.org/ros2/ubuntu $(. /os-release && echo $UBUNTU_CODENAME) main" | sudo tee /etc/apt/sources.list.d/ros2.list > /dev/null
sudo curl -sSL https://raw.githubusercontent.com/ros2/ros2/main/ros2-apt-repository-key.gpg -o /usr/share/keyrings/ros-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/ros-archive-keyring.gpg] http://packages.ros.org/ros2/ubuntu jammy main" | sudo tee /etc/apt/sources.list.d/ros2.list > /dev/null
sudo apt update
sudo apt install ros-humble-desktop ros-dev-tools -y
echo "source /opt/ros/humble/setup.bash" >> ~/.bashrc
source ~/.bashrc
sudo apt update && sudo apt install curl gnupg -y
sudo curl -sSL https://raw.githubusercontent.com/ros2/ros2/main/ros2-apt-repository-key.gpg | sudo gpg --dearmor --yes -o /usr/share/keyrings/ros-archive-keyring.gpg
sudo curl -sSL https://raw.githubusercontent.com/ros/rosdistro/master/ros.key -o /usr/share/keyrings/ros-archive-keyring.gpg
sudo gpg --no-default-keyring --keyring /usr/share/keyrings/ros-archive-keyring.gpg --keyserver hkp://keyserver.ubuntu.com:80 --recv-keys F42ED6FBAB17C654
sudo mkdir -p /root/.gnupg
sudo chmod 700 /root/.gnupg
sudo apt update && sudo apt install dirmngr gnupg curl -y
sudo gpg --no-default-keyring --keyring /usr/share/keyrings/ros-archive-keyring.gpg --keyserver hkp://keyserver.ubuntu.com:80 --recv-keys F42ED6FBAB17C654
sudo apt update
sudo apt install ros-humble-desktop ros-dev-tools -y
echo "source /opt/ros/humble/setup.bash" >> ~/.bashrc
source ~/.bashrc
echo "source /opt/ros/humble/setup.bash" >> ~/.bashrc
source ~/.bashrc
echo "source /opt/ros/humble/setup.bash" >> ~/.bashrc
source ~/.bashrc
sudo apt update
sudo apt install ros-humble-ur ros-humble-ur-simulation-gazebo ros-humble-ur-moveit-config -y
sudo apt update
sudo apt install ros-humble-ur ros-humble-gazebo-ros-pkgs ros-humble-gazebo-ros2-control ros-humble-moveit -y
mkdir -p ~/ros2_ws/src
cd ~/ros2_ws/src
git clone -b humble https://github.com/UniversalRobots/Universal_Robots_ROS2_Gazebo_Simulation.git
cd ~/ros2_ws
rosdep update
rosdep install --from-paths src --ignore-src -y
colcon build
source install/setup.bash
echo "source ~/ros2_ws/install/setup.bash" >> ~/.bashrc
cd ~/ros2_ws
rosdep update
rosdep install --from-paths src --ignore-src -y
colcon build
source install/setup.bash
echo "source ~/ros2_ws/install/setup.bash" >> ~/.bashrc
ros2 launch ur_simulation_gazebo ur_sim_control.launch.py ur_type:=ur3e
cd ~/ros2_ws
code .
cd ~/ros2_ws
code .
cd ~/ros2_ws/src
ros2 pkg create --build-type ament_cmake ur_letter_drawer --dependencies rclcpp moveit_ros_planning_interface geometry_msgs visualization_msgs
#include <rclcpp/rclcpp.hpp>
#include <moveit/move_group_interface/move_group_interface.h>
#include <geometry_msgs/msg/pose.hpp>
#include <visualization_msgs/msg/marker.hpp>
#include <vector>
#include <thread>
int main(int argc, char **argv)
{   rclcpp::init(argc, argv);
}
cd ~/ros2_ws
code .
wsl --shutdown
sudo update-binfmts --enable WSLInterop
sudo apt update && sudo apt install binfmt-support -y
sudo update-binfmts --enable WSLInterop
cd ~/ros2_ws
code .
cd ~/ros2_ws/src
ros2 pkg create --build-type ament_cmake ur_letter_drawer --dependencies rclcpp moveit_ros_planning_interface geometry_msgs visualization_msgs
cd ~/ros2_ws
colcon build --packages-select ur_letter_drawer
source install/setup.bash
ros2 launch ur_letter_drawer draw_letter.launch.py
mkdir -p ~/ros2_ws/src/ur_letter_drawer/launch
nano ~/ros2_ws/src/ur_letter_drawer/launch/draw_letter.launch.py
install(TARGETS
)
install(DIRECTORY launch
)
install(TARGETS
)
install(DIRECTORY launch
)
cd ~/ros2_ws
colcon build --packages-select ur_letter_drawer --cmake-clean-cache
source install/setup.bash
ros2 launch ur_letter_drawer draw_letter.launch.py
~/ros2_ws/src/ur_letter_drawer/CMakeLists.txt
ros2
code .
cd ~/ros2_ws
code .
source /opt/ros/humble/setup.bash
cd ~/ros2_ws
colcon build --packages-select ur_letter_writer --symlink-install --parallel-workers 1
source ~/ros2_ws/install/setup.bash
ros2 launch ur_letter_writer draw_letter.launch.py ur_type:=ur3e letter:=B
source /opt/ros/humble/setup.bash
sudo apt update
sudo apt install ros-humble-ur-simulation-gz
source /opt/ros/humble/setup.bash
ros2 pkg prefix ur_simulation_gz
cd ~/ros2_ws
source /opt/ros/humble/setup.bash
source ~/ros2_ws/install/setup.bash
ros2 launch ur_letter_writer draw_letter.launch.py ur_type:=ur3e letter:=B
source /opt/ros/humble/setup.bash
sudo apt update
sudo apt install ros-humble-ur-simulation-gz
source /opt/ros/humble/setup.bash
cd ~/ros2_ws
colcon build --packages-select ur_letter_writer --symlink-install --parallel-workers 1
source ~/ros2_ws/install/setup.bash
source /opt/ros/humble/setup.bash
source ~/ros2_ws/install/setup.bash
ros2 launch ur_letter_writer draw_letter.launch.py ur_type:=ur3e letter:=O
source /opt/ros/humble/setup.bash
cd ~/ros2_ws
colcon build --packages-select ur_letter_writer --symlink-install --parallel-workers 1
source ~/ros2_ws/install/setup.bash
ros2 launch ur_letter_writer draw_letter.launch.py ur_type:=ur3e letter:=O
wsl --shutdown
source /opt/ros/humble/setup.bash
source ~/ros2_ws/install/setup.bash
export LIBGL_ALWAYS_SOFTWARE=1
export QT_QPA_PLATFORM=xcb
ros2 launch ur_letter_writer draw_letter.launch.py ur_type:=ur3e letter:=O
source /opt/ros/humble/setup.bash
unset QT_QPA_PLATFORM
unset LIBGL_ALWAYS_SOFTWARE
ign gazebo -v 4 -r empty.sdf
source /opt/ros/humble/setup.bash
ign gazebo -s -v 4 /usr/share/ignition/gazebo6/worlds/empty.sdf
source /opt/ros/humble/setup.bash
source ~/ros2_ws/install/setup.bash
ros2 launch ur_simulation_gz ur_sim_moveit.launch.py   ur_type:=ur3e   world_file:=/usr/share/ignition/ignition-gazebo6/worlds/empty.sdf
npm install -g 9router
cd ~/ros2_ws && code .
source /opt/ros/humble/setup.bash
source ~/ros2_ws/install/setup.bash
ros2 launch ur_simulation_gz ur_sim_moveit.launch.py   ur_type:=ur3e   world_file:=/usr/share/ignition/ignition-gazebo6/worlds/empty.sdf
source /opt/ros/humble/setup.bash
source ~/ros2_ws/install/setup.bash
ros2 launch ur_simulation_gz ur_sim_moveit.launch.py   ur_type:=ur3e   world_file:=/usr/share/ignition/ignition-gazebo6/worlds/empty.sdf
source /opt/ros/humble/setup.bash
ros2 launch ur_simulation_gz ur_sim_control.launch.py   ur_type:=ur3e   world_file:=/usr/share/ignition/ignition-gazebo6/worlds/empty.sdf   gazebo_gui:=true   launch_rviz:=false
source /opt/ros/humble/setup.bash
source ~/ros2_ws/install/setup.bash
ros2 run ur_letter_writer draw_initial --ros-args   -p letter:=O   -p use_sim_time:=true
cd ~/ros2_ws
source /opt/ros/humble/setup.bash
ros2 launch ur_simulation_gz ur_sim_control.launch.py   ur_type:=ur3e   world_file:=/usr/share/ignition/ignition-gazebo6/worlds/empty.sdf   gazebo_gui:=true   launch_rviz:=false
source /opt/ros/humble/setup.bash
ign gazebo -r -v 4 /usr/share/ignition/ignition-gazebo6/worlds/empty.sdf
source /opt/ros/humble/setup.bash
source ~/ros2_ws/install/setup.bash
ros2 run ur_letter_writer draw_initial --ros-args   -p letter:=O   -p planning_group:=ur_manipulator   -p use_sim_time:=true
source /opt/ros/humble/setup.bash
export LIBGL_ALWAYS_SOFTWARE=1
ros2 launch ur_simulation_gz ur_sim_control.launch.py   ur_type:=ur3e   world_file:=/usr/share/ignition/ignition-gazebo6/worlds/empty.sdf   gazebo_gui:=true   launch_rviz:=false
